
            <style>
            <?php include 'assets/css/tables.css'; ?>
            </style>
            <h3>LIST BARANG</h3>
            <br>
            <form action='home.php?page=tambahbarang' method='post'> 
                <input  type='submit' name='submit' value='+ Tambah Barang'>
            </form>
            <?php
                require_once("config.php");

                $ambil=$db->prepare("SELECT * FROM barang ");
                $ambil->execute();
                echo "<br> </br>";
                echo "<table id='users' border= 1'>
                <tr>
                <th>Id</th>
                <th>Nama Barang</th>
                <th>Harga Jual (Rp.)</th>
                <th>Harga Beli (Rp.)</th>
                <th>Stok</th>
                <th>Satuan</th>
                <th>Status</th>
                <th>Actions</th>
                </tr>";

                while($row=$ambil->fetch())
                {

                echo "<tr>";
                echo "<td>" . $row['kd_barang'] . "</td>";
                echo "<td>" . $row['nama_barang'] . "</td>";
                echo "<td>" . $row['harga_jual'] . "</td>";
                echo "<td>" . $row['harga_beli'] . "</td>";
                echo "<td>" . $row['stok'] . "</td>";
                echo "<td>" . $row['satuan'] . "</td>";
                $status = $row['status'];
                if ($status == 0){
                    $status = "GUDANG-A" ;
                    echo "<td>" . $status . "</td>";
                    
                }
                else {
                    $status = "GUDANG-B" ;
                    echo "<td>" . $status . "</td>";
                }
                echo "<td><form method='post' action='/superadmin.php?page=editbarang' style='display:inline-block'>
                    <input type='submit' name='edit' value='Edit' />
                    <input type='hidden' name='kd_barang' value=".$row['kd_barang']." />
                    </form>
                    <form method='post' action='/superadmin.php?page=deletebarang' style='display:inline-block'>
                    <input type='submit' name='delete' value='Delete' />
                    <input type='hidden' name='kd_barang' value=".$row['kd_barang']." />
                    </form ></td>"
                    
                    ;
                echo "</tr>";
                }
                
                echo "</table>";
                
                $db=null;
            ?>         
